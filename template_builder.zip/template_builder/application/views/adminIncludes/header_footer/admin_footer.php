<!-- Loading Scripts -->
	<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>js/bootstrap-select.min.js"></script>
	<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>js/jquery.dataTables.min.js"></script>
	<script src="<?php echo base_url(); ?>js/dataTables.bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>js/Chart.min.js"></script>
	<script src="<?php echo base_url(); ?>js/fileinput.js"></script>
	<script src="<?php echo base_url(); ?>js/chartData.js"></script>
	<script src="<?php echo base_url(); ?>js/main.js"></script>
	<script src="<?php echo base_url(); ?>js/bootstrap-filestyle.min.js"></script>
	<!-- angular js -->
	<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
	<!-- My Own Function -->
	<script type="text/javascript" src="<?php echo base_url();?>js/felFunctions.js"></script>\
	<!-- data tooltip -->
	

	<script type="text/javascript">
		$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
		});
	</script>
	<!-- input file design -->
	<script type="text/javascript">
		$(":file").filestyle({buttonName: "btn-primary" size: "sm"});

	</script>
	<!-- time ago -->

	<?php include 'modals.php';?>
	<!-- 
Programmer info: felmerald besario
Position: Web Developer / PHP Programmer
	 -->
</body>
</html>