<!-- Email Account -->

<div id="emailaccount" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
			<h4>Send Account to User</h4>
			<span class="glyphicon glyphicon-remove text-danger pull-right" data-dismiss="modal" style="margin-top: -30px;">
			</div>
				<div class="modal-body">
	<form action="<?php echo base_url('admin_controller/email');?>" method="post" accept-charset="utf-8">
					<div class="form-group">
						<input type="text" id="name" name="name" class="form-control" placeholder="Fullname">
					</div>
					<div class="form-group">
						<input type="email" id="email" name="email" class="form-control" placeholder="Email">
					</div>
					
					<div class="form-group">
						<textarea id="message" name="message" cols="5" rows="5" class="form-control" placeholder="Message"></textarea>
					</div>
					<br/>
					<input type="submit" id="submit" name="submit" value="Send" class="btn btn-warning btn-sm">
				</div>
	</form>
			<div class="modal-footer">
			</div>
		</div>
	</div>
</div>


<!-- delete user -->
<?php $displayuser = $this->db->get('account'); foreach($displayuser->result() as $data):?>
<div id="deleteuser<?php echo $data->id;?>" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content m-content">
			<div class="modal-header">
			<span class="glyphicon glyphicon-remove text-danger pull-right close" data-dismiss="modal" style="margin-top: 0px;"></span>
			<?php $this->db->where('id',$data->id);$query = $this->db->get('account');foreach($query->result() as $delete): ?>
			<h4><span class="glyphicon glyphicon-trash text-danger"></span> Are you sure you want to Delete <br/>
			 <strong class="text-danger"><?php echo strtoupper($delete->firstname.' '.$delete->lastname);?></strong>
			 Account ?
			 </h4>
			<?php endforeach; ?>
			<hr>
			<button type="button" data-dismiss="modal" class="btn btn-success btn-sm"> NO </button>
			<a href="dashboard_deleteuseraccount?id=<?php echo $data->id;?>" type="submit" class="btn btn-danger btn-sm pull-right"> YES </a>
			</div>
			
		</div>
	</div>
</div>
<?php endforeach;?>
<!-- for update account use -->
<?php $update = $this->db->get('account'); foreach($update->result() as $data):?>
<div id="updateuser<?php echo $data->id;?>" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">	
		<div class="modal-content m-content">
			<div class="modal-header m-header">
			<?php $this->db->where('id',$data->id); $query = $this->db->get('account');foreach($query->result() as $edit): ?>
				<span class="glyphicon glyphicon-remove text-danger pull-right close" data-dismiss="modal" style="margin-top: 0px;"></span>
				<strong><span class="glyphicon glyphicon-edit"></span> UPDATE <?php echo strtoupper($edit->firstname);?> ACCOUNT ? </strong>
			</div>
				<div class="modal-body">
				<?php echo form_open(base_url().'dashboard_updateUserAccount');?>
				<input type="hidden" name="id" value="<?php echo $edit->id;?>">

				<div class="form-horizontal">
				

					 <div class="form-group">
					    <label for="input1" class="col-lg-2 control-label">Firstname</label>
					    <div class="col-lg-10">
					      <input type="text" class="form-control" name="firstname" id="input1" value="<?php echo  $edit->firstname; ?>">
					    </div>
					 </div>
					 <div class="form-group">
					    <label for="input2" class="col-lg-2 control-label">Lastname</label>
					    <div class="col-lg-10">
					      <input type="text" class="form-control" name="lastname" id="input2" value="<?php echo $edit->lastname; ?>">
					    </div>
					 </div>


				</div>

				</div>
					<div class="modal-footer m-footer">
					<button type="submit" class="btn btn-sm btn-warning"><span class="glyphicon glyphicon-ok"></span> UPDATE</button>
					</div>
					<?php echo form_close();?>
			<?php endforeach; ?>
		</div>
	</div>
</div>
<?php endforeach; ?>

<!-- for show all recent -->
<div id="showall_recent" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content m-content">
			<div class="modal-header m-header">
				<span class="glyphicon glyphicon-remove text-danger pull-right close" data-dismiss="modal" style="margin-top: 0px;"></span>
			</div>

			<div class="modal-body">
			<?php foreach($getRecents as $offset):?>
				<hr class="dash"/>
				<small><span class="fa fa-angle-right"></span>
				<strong class="recent-name-color"><?php echo ucfirst(strtoupper($offset->firstname)); ?></strong>
				downloade <?php echo $offset->times; ?> times <u><?php echo ucwords(strtolower($offset->template_name)); ?></u> on <?php echo $offset->downloaded; ?>
				</small>
				<hr class="dash"/>
			<?php endforeach; ?>
			</div>

		</div>
	</div>
</div>