<div class="container">


			<div class="row">
				<center>
				<!-- logo -->

					<img src="<?php echo base_url();?>images/logo/builder.png" class="responsive-img login-logo" alt="Template Builder Logo" style="height: 100px; margin-bottom:-90px;margin-top: 50px;">


				<!-- end logo -->
				<div class="card-panel" style="width: 70%;height: auto; background-color: #bdced7; margin-top: 100px;">
                    <?php echo $this->session->flashdata('login_error'); ?>
                    <?php echo form_open(base_url().'user_login'); ?>
				<!-- login form -->
				<div class="row">
                  
					<div class="input-field col s12">
							          <i class="material-icons prefix">email</i>
							          <input id="icon_prefix" type="email" class="validate" name="email">
							          <label for="icon_prefix">Email</label>
                                        <center><p style="color: red;"><?php echo form_error('email'); ?></p></center>
			        </div>

			        <div class="input-field col s12">

						        	<i class="material-icons prefix">vpn_key</i>
						        	<input id="icon_password" type="password" class="validate" name="password">
						        	<label for="icon_password">Password</label>
                         <center><p style="color: red;"><?php echo form_error('password'); ?></p></center>
			        </div>

			        <div class="col s12">
			        	<input type="submit" class="waves-effect waves-light btn" style="float:left;margin-left: 45px;" value="Login">
			        </div>
                    
                    <?php echo form_close(); ?>
		        </div>
				<!-- end -->


				</div>
				</center>
			</div>



</div>
	

