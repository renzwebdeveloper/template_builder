<!-- load navigation menu top -->
<?php include 'include_files/top-nav-menu.php';?>
<!-- end -->
	<div class="ts-main-content">
	<!-- load left sidebar -->
		<?php include 'include_files/left_sidebar.php';?>
	<!-- end -->
		<div class="content-wrapper">
			<div class="container-fluid">

				<div class="row">
					<div class="col-md-9">



						
						

					</div>

					<div class="col-md-3">

							<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">



									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="headingOne" style="background-color: #484e6e;">
											<h4 class="panel-title">
									        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
									        <span class="fa fa-cloud-upload text-warning"></span>
									          Upload Image One
									        </a>
									      </h4>
										</div>
										<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
											<div class="panel-body">

											<div class="form-group">
												<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
											</div>

											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="headingTwo" style="background-color: #484e6e;">
											<h4 class="panel-title">
										        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
										        <span class="fa fa-cloud-upload text-warning"></span>
										          Upload Image Two
										        </a>
										      </h4>
										</div>
										<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
											<div class="panel-body">
												
												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>

											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="headingThree" style="background-color: #484e6e;">
											<h4 class="panel-title">
									        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
									        <span class="fa fa-cloud-upload text-warning"></span>
									          Upload Image Three
									        </a>
									      </h4>
										</div>
										<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
											<div class="panel-body">
												

												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>


											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="heading4" style="background-color: #484e6e;">
											<h4 class="panel-title">
										        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapseThree">
										        <span class="fa fa-cloud-upload text-warning"></span>
										          Upload Image Four
										        </a>
										      </h4>
										</div>
										<div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4">
											<div class="panel-body">
											
												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>


											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="heading5" style="background-color: #484e6e;">
											<h4 class="panel-title">
										        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapseThree">
										        <span class="fa fa-cloud-upload text-warning"></span>
										          Upload Image Five
										        </a>
										      </h4>
										</div>
										<div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
											<div class="panel-body">
												
												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>

											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="heading6" style="background-color: #484e6e;">
											<h4 class="panel-title">
										        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapseThree">
										        <span class="fa fa-cloud-upload text-warning"></span>
										          Upload Image Six
										        </a>
										      </h4>
										</div>
										<div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6">
											<div class="panel-body">
												
												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>


											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="heading7" style="background-color: #484e6e;">
											<h4 class="panel-title">
										        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse7" aria-expanded="false" aria-controls="collapseThree">
										        <span class="fa fa-cloud-upload text-warning"></span>
										          Upload Image Seven
										        </a>
										      </h4>
										</div>
										<div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading7">
											<div class="panel-body">
												
												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>

											</div>
										</div>
									</div>


									<div class="panel panel-default" style="border-radius: 0px;background-color: #3d415a">
										<div class="panel-heading" role="tab" id="heading8" style="background-color: #484e6e;">
											<h4 class="panel-title">
										        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="false" aria-controls="collapseThree">
										        <span class="fa fa-cloud-upload text-warning"></span>
										          Upload Image Eight
										        </a>
										      </h4>
										</div>
										<div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8">
											<div class="panel-body">
												
												<div class="form-group">
													<input type="file" name="userfile" class="filestyle" data-buttonName="btn-primary" data-size="sm" required="">
												</div>

											</div>
										</div>
									</div>

									<br>

									<div class="form-group">
										<button type="submit" class="btn btn-sm btn-warning btn-lg form-control"><span class="fa fa-cloud-upload"></span> 
										Upload
										</button>
									</div>






								</div>


									<div class="well" style="border-radius: 0px;background-color: #3d415a">
									<div class="form-group">
										<label style="color:white"> Change Skin:</label>
										<select class="form-control input-sm" name="skin_activate" style="border-radius: 0px">
											<option>
												
											</option>
											<option></option>
										</select>
										<br>
										<button type="submit" class="btn btn-warning btn-sm"><span class="fa fa-exchange"></span> Change </button>
									</div>
							</div>



					</div>


				</div>

			</div>
		</div>
	</div>
