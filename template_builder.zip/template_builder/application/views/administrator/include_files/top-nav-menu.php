<div class="brand clearfix">
		<a href="<?php echo base_url(); ?>dashboard" class="logo"><img src="<?php echo base_url();?>img/logo/horizontal-logo.png" class="img-responsive"></a>
		<span class="menu-btn"><i class="fa fa-bars"></i></span>
		<ul class="ts-profile-nav">
			<li class="ts-account">
				<a href="#"><img src="<?php echo base_url();?>img/profile.png" class="ts-avatar hidden-side" alt=""> 
				<?php foreach($getdetails as $admin):?>
					<?php echo ucfirst($admin->firstname);?>
				<?php endforeach;?>
				 <i class="fa fa-angle-down hidden-side"></i></a>
				<ul>
					<li><a href="<?php echo base_url();?>">My Account</a></li>
					<li><a href="<?php echo base_url();?>admin_logout">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
