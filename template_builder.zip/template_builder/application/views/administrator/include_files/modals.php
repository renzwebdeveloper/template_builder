 <!-- modal:add user -->
<!-- <div id="adduser" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	<div class="modal-dialog" >
		<div class="modal-content m-content"style="border-radius: 0px;">
			<div class="modal-header m-head">
				<span class="text-muted glyphicon glyphicon-remove pull-right" data-dismiss="modal"></span>
			</div>
				<div class="modal-body">
										</div>
				<div class="modal-footer m-footer">
				</div>
		</div>
	</div>
</div>  -->