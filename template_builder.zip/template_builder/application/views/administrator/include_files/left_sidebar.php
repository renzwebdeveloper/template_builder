<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
				<li>
					<p class="sidebar-class-last-loggedIn">
											<?php foreach($lastloggedin as $data):?>
												<?php if($data->last_login == ""){ ?>

													<p class="text-danger"><i class="fa fa-key text-danger"></i> <small class="black">You're Last Logged In : </small> No result!</p>

													<?php }else{ ?>

														<p class="text-success" style="padding-left: 5px"><i class="fa fa-key text-danger" style="color:Red"></i> <small class="black" style="color:white">You're Last Logged In : </small>
													
														<?php echo  $this->admin_model->time_ago($data->last_login);?>
														
														</p>
												<?php } ?>
											
											<?php endforeach;?>
					</p>
					<hr/>
				</li>
				<li class="open"><a href="<?php base_url() ?>dashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				
			
				<li><a href="#"><i class="fa fa-files-o"></i> Templates</a>
					<ul>
						<li><a href="<?php echo base_url();?>dashboard_addTemplate" ><span class="text-warning glyphicon glyphicon-plus"></span> Add</a></li>
						<li><a href="<?php echo base_url();?>"><span class="text-warning glyphicon glyphicon-pencil"></span> Manage</a></li>
					</ul>
				</li>
				<hr/>

		
				<li><a href="#"><i class="fa fa-bar-chart"></i> Recent Activities <span class="badge pull-right"><?php echo $this->db->count_all_results('recent_activity'); ?></span></a>
					<ul>
					<!-- comes from joining table -->
					<?php if($getrecentActivities->num_rows() != 0){ ?>
						<?php foreach($getrecentActivities->result() as $recent): ?>
							<hr class="dash"/>
							<li>
							
								<small class="recent-color"><span class="fa fa-angle-right"></span>
									<strong class="recent-name-color">
										<?php echo ucfirst(strtoupper($recent->firstname)); ?>
									</strong> downloaded <?php echo $recent->times; ?> times <u> <?php echo strtolower($recent->template_name); ?></u> on <?php echo $recent->downloaded; ?>
								</small>

							</li>
							<hr class="dash"/>
						<?php endforeach; ?>
									<a href="#showall_recent" data-toggle="modal" class="text-warning pull-right"><small>Show All</small></a>
					<?php }else{ ?>
						<li><small class="recent-color"><span class="fa fa-angle-right"></span> No Recent!</small></li>
					<?php } ?>
					</ul>
				</li>
					
				

				<!-- Account from above kung ma mobile ni -->
				<ul class="ts-profile-nav">
					
					<li class="ts-account">
						<a href="#"><img src="<?php echo base_url();?>img/profile.png" class="ts-avatar hidden-side" alt=""><i class="fa fa-angle-down hidden-side text-warning" style="color:Red"></i></a>
						<ul>
							<li><a href="<?php echo base_url();?>">My Account</a></li>
							<li><a href="<?php echo base_url();?>">Logout</a></li>
						</ul>
					</li>
				</ul>

			</ul>
		</nav>