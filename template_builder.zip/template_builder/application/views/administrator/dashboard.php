<!-- load navigation menu top -->
<?php include 'include_files/top-nav-menu.php';?>
<!-- end -->
	<div class="ts-main-content">

	<!-- load left sidebar -->
		<?php include 'include_files/left_sidebar.php';?>
	<!-- end -->
		<div class="content-wrapper">
			<div class="container-fluid">
			<!-- flashdata welcome admin alert if login success -->
			<?php echo $this->session->flashdata('login_successful'); ?>
			<!-- end -->
				<div class="row">
					<div class="col-md-12">
					<!-- flashdata -->
					<?php echo $this->session->flashdata('deleteUser_success');?>
					<?php echo $this->session->flashdata('update_success');?>
					<!-- end -->

						<div class="row">
							<div class="col-md-6">
								<div class="panel panel-default" style="border-radius: 0px">
									<div class="panel-heading">
									<span class="text-warning glyphicon glyphicon-plus"></span> Add User Account

									</div>
									<div class="panel-body">
											<!-- flashdata -->
												<?php echo $this->session->flashdata('added_true');?>
											<!-- end -->

			<!-- start angular -->
					<div ng-app="">
							<h5>
							<strong><span class="glyphicon glyphicon-plus text-warning"></span> <span class="glyphicon glyphicon-user text-success"></span> :</strong>
							{{firstname}} {{lastname}} {{email}} {{password}}
							</h5>
										<div class="row">
											<div class="col-md-12">

							<form role="form" action="<?= base_url().'dashboard_add_userAccount'?>" method="post" >
											
												<input type="hidden" name="role" value="user">
												<div class="form-group">
													<input type="text" ng-model="firstname" name="firstname" class="form-control no-radius" placeholder="Firstname">
													<p style="color:red"><?php echo form_error('firstname');?></p>
												</div>
											
											
												<div class="form-group">
													<input type="text" ng-model="lastname" name="lastname" class="form-control no-radius" placeholder="Lastname">
													<p style="color:red"><?php echo form_error('lastname');?></p>
												</div>
										
											
												<div class="form-group">
													<input type="text" ng-model="email" name="email" class="form-control no-radius" placeholder="Email">
													<p style="color:red"><?php echo form_error('email'); ?></p>
												</div>
																					
												<div class="form-group">
													<input id="textPassword" type="password" ng-model="password" name="password" class="form-control no-radius" placeholder="Password" onkeyup="CheckPasswordStrength(this.value)">
													<span id="password_strength"></span>
													<p style="color:red"><?php echo form_error('password');?></p>
												</div>
												<div class="form-group">
													<input id="verify" type="password" name="cpassword" class="form-control no-radius" placeholder="Confirm Password">

													<p id="verifynote" class="text-danger hidden"><span class="glyphicon glyphicon-warning-sign text-danger">					
													</span>
														Password Does Not Match!
													</p>


													<p style="color:red"><?php echo form_error('cpassword');?></p>
												</div>
												<div class="form-group">
													<button type="submit" class="btn btn-sm btn-success no-radius pull-right"><span class="glyphicon glyphicon-plus"></span> Add</button>
												</div>
									</form>
											</div>
										</div>
								</div>
								<!-- end angular -->
									</div>
								</div>
							</div>
							<div class="col-md-6">
							<div class="row">
								<div class="col-md-12">
										<div class="panel panel-default" style="border-radius: 0px; height: 498px;overflow-y: scroll;">
											<div class="panel-heading">
												<span class="fa fa-users text-warning"></span>
												User's Last Logged In
											</div>
											<div class="panel-body">


								<?php foreach($userlastloggedin as $userlog):?>
										<?php if($userlog->role !="admin" && $userlog->last_login != null): ?>
										<p class="black"><span class="fa fa-key text-danger"></span> 
											<?php echo ucwords(strtolower($userlog->lastname.', '.$userlog->firstname.'
											<small class="text-muted pull-right" style="float:right;word-keep:keep-all; margin-top:3px">'.$this->admin_model->time_ago($userlog->last_login).'</small>'));?>
										</p>
										<?php endif; ?>
								<?php endforeach;?>
							
											
											</div>
										</div>
								</div>

							</div>

							</div>

							<div class="col-md-12">
								<div class="panel panel-default" style="border-radius: 0px;">
									<div class="panel-heading">
									<span class="glyphicon glyphicon-user text-warning"></span> User's
									<!-- <a href="#adduser" data-toggle="modal" class="btn btn-warning btn-sm pull-right" style="margin-top: -4px;"><span class="glyphicon glyphicon-plus"></span> Add user</a>
									</div> -->
									<div class="panel-body">
									
									<div class="table-responsive">
										<table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
											<thead>
												<tr>
													<th class="text-primary">Firstname</th>
													<th class="text-primary">Lastname</th>
													<th class="text-primary">Email</th>
													<th class="text-primary">Created</th>
													<th class="text-primary">Modified</th>
													<th class="text-primary">Option</th>
												</tr>
											</thead>
								
												<tbody>
									<?php foreach($displayuser as $data):?>
										<?php if($data->role == "user"){ ?>
													<tr>
														<td><?php echo ucfirst(strtolower($data->firstname)); ?></td>
														<td><?php echo ucfirst(strtolower($data->lastname)); ?></td>
														<td><?php echo $data->email; ?></td>
														<td><?php echo $data->created;?></td>
														<td>

														<?php if($data->modified != 0){ ?>
															<?php echo $data->modified; ?>
														<?php }else{ ?>
															<small class="word-break text-danger"></small>
															<span class="glyphicon glyphicon-warning-sign text-warning"></span> Not Yet Modified
														<?php } ?>

														</td>
														<td>
														<!-- for delete -->
															<a href="#deleteuser<?php echo $data->id;?>" data-toggle="modal" class="btn btn-danger btn-xs"><span class="fa fa-trash" data-toggle="tooltip" title="Trash?"></span></a>

														<!-- for update -->

															<a href="#updateuser<?php echo $data->id;?>" data-toggle="modal" class="btn btn-warning btn-xs"><span class="fa fa-edit" data-toggle="tooltip" title="UPDATE?"></span></a>

														<!-- send message -->

															<a href="#emailaccount" data-toggle="modal" class="btn btn-success btn-xs"><span class="fa fa-envelope-o" data-toggle="tooltip" title="Send this account"></span></a>


														</td>
													</tr>
										<?php }?>

										<?php endforeach; ?> 		
										</tbody>
								</table>

									</div>


									</div>
								</div>
							</div>

						</div>
						

					</div>
				</div>

			</div>
		</div>
	</div>


<!-- modal sa add user -->
<?php include 'include_files/modals.php';?>