
		<div class="form-content">
			<div class="container">
				<div class="row">
				<br><br><br>
					<div class="col-md-6 col-md-offset-3">
						<center>
							<img src="<?php echo base_url();?>img/logo/builder.png" class="img-responsive" alt="" style="height: 80px">
						</center>
						<div class="well row pt-2x pb-3x bk-light" style="border-radius: 0px;">
							<h4 class="text-warning text-center"><?php echo ucwords(strtolower($login));?><hr class="hr" /></h4>
							<?php echo $this->session->flashdata('login_error'); ?>
							<div class="col-md-8 col-md-offset-2">
								
								<?php echo form_open(base_url().'admin_login'); ?>
									<label for="" class="text-uppercase text-sm">Email</label>
									<input type="email" name="email" placeholder="Email" class="form-control mb no-radius" style="border-radius: 0px;">

									<label for="" class="text-uppercase text-sm">Password</label>
									<input type="password" name="password" placeholder="Password" class="form-control mb no-radius" style="border-radius: 0px;">

									<div class="checkbox checkbox-circle checkbox-info">
										<input id="checkbox7" type="checkbox" name="remember">
										<label for="checkbox7">
											Keep me signed in
										</label>
									</div>

									<button class="btn btn-primary btn-block" type="submit" style="border-radius: 0px;">LOGIN</button>
								<?php echo form_close();?>
							
							</div>
						</div>
						<div class="text-center text-light">
							<a href="#" class="text-light">Forgot password?</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	