  <nav class="blue-grey teal darken-4" style="opacity: 0.8;filter: Alpha(opacity=50);">
  <div class="container">
    <div class="nav-wrapper">

    	<h5 class="nav-color-text"><?php echo $header; ?></h5>
    
    </div>
  </div>
</nav>