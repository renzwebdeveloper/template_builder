<header>
	
</header><!-- /header -->
<main>
	
</main>
<footer class="fel-footer-admin" style="opacity: 0.8;filter: Alpha(opacity=50)">
      
          <div class="footer-copyright">
            <div class="container">
            &copy <?php echo date('Y'); ?> Template Builder
            
            </div>
          </div>
 </footer>


   



<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/materialize.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jobhunting_function.js"></script>


</body>
</html>