<!DOCTYPE html>
<html>
<head>
	<!-- Author: Besario, Felmerald Calago-->
	<title><?php echo $title; ?></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  			<!-- cascading stylesheet -->
  		<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/materialize.css">
  		<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/mystyle.css">
  		
</head>
<body style="background-image: url(images/admin/net_background.jpg); background-size: cover;">