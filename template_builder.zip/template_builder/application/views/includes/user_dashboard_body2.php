<body>
    
    <!-- SIDE NAV PUSH CONTENT -->
   
   <div id="mySidenav" class="sidenav z-depth-2">
            <!-- <div class="nav-wrapper"> -->
        
       <a href="#" style="color: #a3a3a3;" class="text" id="side-nav-head"><h6>Dashboard</h6></a>
                
                <a href="javascript:void(0)" id="openbtn" class="closebtn" onclick="openNav()"><i class="small material-icons">skip_next</i></a>
                 
                <a style="visibility: hidden;" href="javascript:void(0)" id="closebtn" class="closebtn" onclick="closeNav()"><i class="small material-icons">skip_previous</i></a>
               
               
            <!--</div>-->
            
      
    <!-- CONTENT OF THE SIDE NAV-->
              
       <ul style="border: 1px solid #2b2a2a;" class="collection with-header">
           
        <li style="background-color: #383838; color: #a3a3a3; border-bottom: 1px solid #2b2a2a;" class="collection-item"><a class="content-side-nav-renz" href=""><h6>Alvin</h6></a></li>
           
        <li style="background-color: #383838; color: #a3a3a3; border-bottom: 1px solid #2b2a2a;" class="collection-item"><a class="content-side-nav-renz" href=""><h6>Alvin</h6></a></li>
           
        <li style="background-color: #383838; color: #a3a3a3; border-bottom: 1px solid #2b2a2a;" class="collection-item"><a class="content-side-nav-renz" href=""><h6>Alvin</h6></a></li>
           
        <li style="background-color: #383838; color: #a3a3a3; border-bottom: 1px solid #2b2a2a;" class="collection-item"><a class="content-side-nav-renz" href=""><h6>Alvin</h6></a></li>
           
        <li style="background-color: #383838; color: #a3a3a3; border-bottom: 1px solid #2b2a2a;" class="collection-item"><a class="content-side-nav-renz" href=""><h6>Alvin</h6></a></li>
           
        <li style="background-color: #383838; color: #a3a3a3; border-bottom: 1px solid #2b2a2a;" class="collection-item"><a class="content-side-nav-renz" href=""><h6>Alvin</h6></a></li>
        
      </ul>
    <!-- CONTENT OF THE SIDE NAV CLOSE-->
           
    </div>
    <!-- SIDE NAV PUSH CONTENT CLOSE -->
    
    <!-- MAIN DIV  -->
  
        <div id="main"> 
            <div class="row">
                <div class="col-xs-6"> </div>
                <div class="col-xs-6"> </div>
            </div>
        </div>

    
    <!-- MAIN DIV CLOSE-->
   
    <!-- INTERNAL CSS -->
    <style>
            body {
            font-family: "Calibri";
        }

        .sidenav {
          
            width: 30px;
            position: fixed;
            z-index: 1;
            top: 70px;
            left: 0;
            background: #4a4a4a;
            overflow-x: hidden;
            transition: 0.5s;
            height: 100%;
           
           
        }

        .sidenav a {
          
            text-decoration: none;
            font-size: 25px;
            color: #818181;
            display: block;
            transition: 0.3s
        }

        .sidenav a:hover, .offcanvas a:focus{
            color: #f1f1f1;
        }

        .closebtn {
            position: absolute;
            top: 0;
            right: 0px;
            margin-left: 0px;
            font-size: 5px;
           
        }

        #main {
            transition: margin-left .5s;
            padding: 16px;
            height: 100%;
            display: block;
            width: 96%;
            margin-left: 40px;
            margin-right: 40px;
           
         
        }

        @media screen and (max-height: 450px) {
          .sidenav {padding-top: 15px;}
          .sidenav a {font-size: 18px;}
        }
        #sidenav-nav{
        margin-top: 0px;
        }
        #side-nav-head{
            visibility: hidden;
            text-align: center;
        }
        #side-nav-content{
            visibility: hidden;
            text-align: center;
        }
        .nav-wrapper{
            background-color: rgba(69,139,116,0.2);
        }
        .nav-wrapper2{
            background-color: grey;
        }
        #side-nav-content{
            text-align: center;
        }
        #side-nav-content-li{
            align-self: center;
        }
        #side-nav-content-ul{
            align-self: center;
        }
        #collection2{
            background-color: white;
            border-top: 1px solid #8B8378;
            
        }
        .text{
            font-family: "Calibri";
            font-size: 20px;
            text-align: left;
            text-transform: capitalize;
            color: black;
            vertical-align: middle;
        }
        .collection1{
            border-bottom: 1px solid #8B8378;
        }
      
        </style>
    <!-- INTERNAL CSS CLOSE-->
    
    <!-- CREATED BY: RENZ DAITOL-->
    
</body>