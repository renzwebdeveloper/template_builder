<header>
	
</header><!-- /header -->
<main>
	
</main>
<footer class="fel-footer">
      
          <div class="footer-copyright">
            <div class="container">
            &copy <?php echo date('Y'); ?> Template Builder
            <a class="grey-text text-lighten-4 right" href="#!">Contact Us</a>
            </div>
          </div>
 </footer>


   



<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/materialize.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jobhunting_function.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/renzdaitol.js"></script>


</body>
</html>