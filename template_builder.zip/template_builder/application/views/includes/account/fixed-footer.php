<header ></header><!-- /header -->
<main></main>

   <footer class="page-footer">
        
          <div class="footer-copyright">
            <div class="container">
            <a class="grey-text text-lighten-4 right" href="#!">&copy <?php echo date('Y'); ?> Template Builder</a>
            </div>
          </div>
  </footer>

        