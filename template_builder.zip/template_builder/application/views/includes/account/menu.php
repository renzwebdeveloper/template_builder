<nav class="blue-grey darken-1" >
 
  <ul class="right hide-on-med-and-down" style="opacity: 0.5;filter: Alpha(opacity=50);">
    
     <li><a class="dropdown-button" href="#!" data-activates="dropdown1">Account Settings<i class="mdi-navigation-arrow-drop-down right"></i></a></li>
      <ul id='dropdown1' class='dropdown-content'>
        <li><a href="<?php echo base_url(); ?>admin_logout">Logout</a></li>
        <li><a href="#!">Account</a></li>
      </ul>
    </ul>
  </ul>
  <ul id="slide-out" class="side-nav fixed">
  <!-- search here -->
    <nav class="blue-grey darken-4">
    <div class="nav-wrapper">
        
        <!-- profile -->
        <div class="chip">
          <img src="images/admin/dolphin.jpg" alt="Contact Person">
          <?php foreach($getdetails as $row): ?>
            <?php echo ucwords(strtolower($row->firstname.' '.$row->lastname));?>
          <?php endforeach; ?>
        </div>
        <!-- end -->


    </div>
  </nav>
  <!-- end -->
  <!-- collapse -->
  <ul class="collapsible " data-collapsible="accordion" style="color:black;">
    <li>
<!-- firs -->
      <div class="collapsible-header word-break" style="color:black"><i class="material-icons text-success">settings</i>Settings</div>
<!-- sa collapse nga body -->
      <div class="collapsible-body">
       <p style="color:black">
      <a href="#">Add Templates</a>
      <a href="#">Manage Templates</a>
       </p>
      </div>
<!-- end -->
<!-- end sa first -->
    </li>
    
  </ul>
  <!-- end -->


      <!-- collapse -->
  <ul class="collapsible" data-collapsible="accordion" style="color:black">
    <li>
<!-- firs -->
      <div class="collapsible-header word-break"><i class="material-icons text-warning">verified_user</i> Users</div>
<!-- sa collapse nga body -->
      <div class="collapsible-body">
       <p style="color:black">
       <!-- modal ni -->
        <a href="#">Add User</a>
        <a href="#">Generate user and count <span class="badge">14</span> </a>
       
       </p>
      </div>
<!-- end -->
<!-- end sa first -->
    </li>
    
  </ul>
  <!-- end -->
 


    </ul>
    <a href="#" data-activates="slide-out" class="button-collapse show-on-large"><i class="mdi-navigation-menu"></i></a>
</nav>

