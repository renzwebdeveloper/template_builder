<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/materialize.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jobhunting_function.js"></script>


</body>
</html>