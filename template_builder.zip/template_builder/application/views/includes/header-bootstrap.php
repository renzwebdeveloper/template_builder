<html>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/materialize.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/mystyle.css">