<body>
    
    <!-- MY PROFILE BODY -->
    <div id="renz-myprofile-container" style="margin-top: 20px;" class="container">
        
      <div style="opacity: 1; border-radius: 15px;background-color: white; padding: 15px 15px;" class="row">
            <!-- TITLE -->
             <div style="border-radius: 15px; color: white; background-color: #008B8B;" class="center col s12">
                 <h4>My Profile</h4>
             </div>
             
             
  <div class="row">
      <div class="left col s6">

           <div class="center">
               <img style="margin-top: 15px; border: 2px solid grey; border-radius: 15px; border: 0px solid red;" src="<?php echo base_url();?>images/avatar/profile.jpg"; width="90%"; height="90%";>
           </div>

       </div>
            
             
            
   <div class="right col s6">

   <div class="center">
             <?php echo $this->session->flashdata('login_error'); ?>
   <div class="row">
        <?php foreach($user_details as $info): ?>
   <div style="padding: 30px 30px; background-color: ;" class="col s12">
      
        <?php echo form_open(base_url().'update_user_data2'); ?>
        
          <input name="id" id="password" type="hidden" class="validate" value="<?php echo $info->id; ?>">
        
   <div class="row">
        <div class="input-field col s6">
          <input name="firstname" id="first_name" type="text" class="validate" value="<?php echo ucwords(strtolower($info->firstname));?>">
            
          <label for="first_name">Firstname</label>
        </div>
       
       <center>
           <p style="color: red;"><?php echo form_error('firstname'); ?></p>
       </center>
          
          
        <div class="input-field col s6">
          <input name="lastname" id="last_name" type="text" class="validate" value="<?php echo ucwords(strtolower($info->lastname));?>">
            
          <label for="last_name">Lastname</label>
        </div>
   </div>
        <center>
            <p style="color: red;"><?php echo form_error('lastname'); ?></p>
        </center>
        
   <div class="row">
        <div class="input-field col s6">
          <input name="email" id="last_name" type="text" class="validate" value="<?php echo $info->email; ?>">
            
          <label for="last_name">Email Address</label>
        </div>
              
       <center>
           <p style="color: red;"><?php echo form_error('email'); ?></p>
       </center>
             
   <div class="input-field col s6">
        <input name="type" id="last_name" type="text" class="validate" value="<?php echo $info->role; ?>">
       
        <label for="last_name">Type</label>
   </div>
       
  </div>
       <center>
             <p style="color: red;"><?php echo form_error('type'); ?></p>
       </center>
      
      <div class="row">
        <div class="input-field col s12">
          <input name="password" id="password" type="password" class="validate" value="<?php echo $info->password; ?>">
          <label for="password">Password</label>
        </div>
      </div>
        
         <div class="row">
        <div class="input-field col s12">
          <input name="new_password" id="password" type="password" class="validate">
          <label for="password">New Password</label>
        </div>
      </div>
         <center><p style="color: red;"><?php echo form_error('new_password'); ?></p></center>
        
         <div class="row">
        <div class="input-field col s12">
          <input name="confirm_password" id="password" type="password" class="validate">
          <label for="password">Confirm Password</label>
        </div>
      </div>
         <center><p style="color: red;"><?php echo form_error('confirm_password'); ?></p></center>
        
       
        <div class="row">
            <!--<a class="waves-effect waves-light btn-large">Save</a>-->
          <input type="submit" class="waves-effect waves-light btn-large" value="Save">
            <a class="waves-effect waves-light btn-large">Cancel</a>
        </div>
      <?php echo form_close(); ?>
    </div>
        <?php endforeach; ?>
  </div>  
    
                   </div>

                 </div>
            </div>
            
             
        </div>
        
    </div>
    
   
</body>