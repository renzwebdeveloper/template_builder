<!-- Created by: Renz Daitol -->
<div class="navbar-fixed">

<nav id="nav-upper" class="blue-grey darken-1">
    <div id="nav-upper" class="nav-wrapper">

      <a href="#!" class="center brand-logo"><img style="margin-top:0%" src="images/logo/horizontal-logo.png" height="75" width="250"></a>
      <a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>

      
        <ul id="nav-mobile" class="left hide-on-med-and-down">
            <li>
                <a class='dropdown-button' href='user_dashboard' data-activates='dropdown_boards'>Dashboard</a>
            </li>

            <li>
                 <div class="input-field col s6">
                    <i class="material-icons prefix">search</i>
                    <input id="icon_telephone" type="tel" class="validate">
                    <label id="fullscreen-search-label" for="icon_telephone">Search</label>
                 </div>
            </li>
      </ul>
        
      <ul class="right hide-on-med-and-down">
       
          <li>
             <div class="chip">
                 
                <img src="images/avatar/profile.jpg" alt="Contact Person">
                 <!-- TO DISPLAY THE DATA FROM THE CONTROLLER -->
                 <?php foreach($user_details as $info): ?>
                    <?php echo ucwords(strtolower($info->firstname.' '.$info->lastname)); ?>
                 <?php endforeach ?>
                 <!-- TO DISPLAY THE DATA FROM THE CONTROLLER END -->
             </div>
              
          </li>
          
        <li>
           
            <a class='dropdown-button' href='#' data-activates='dropdown_boards4'><i class="material-icons">view_stream</i></a>
        </li>
          
            
      </ul>

        <!-- MOBILE MODE -->
        
       
       <ul class="side-nav" id="mobile-demo">
         
             <li id="mobile-li">
                 <div class="input-field col s6">
                    <i class="material-icons prefix">search</i>
                    <input id="icon_telephone" type="tel" class="validate">
                    <label id="mobile-search-label" for="icon_telephone">Search</label>
                 </div>
             </li>

                <li id="mobile-li">
                    <a href="#"><p id="font-color">Boards</p></a>
                </li>

                <li id="mobile-li">
                    <a href="profile"><p id="font-color">Profile</p></a>
                </li>
                <li id="mobile-li">
                     <a href="user_logout"><p id="font-color">Logout</p></a>
                </li>
        </ul>
        
         <!-- Dropdown Trigger -->
 
  <!-- Dropdown Structure -->
 
        
  <ul id='dropdown_boards4' class='dropdown-content'>
    
      <li><a href="profile">Profile</a></li>
      <li><a href="user_logout">Logout</a></li>
  </ul>
   
   
    </div>
    
    <!-- Internal Style Sheet -->
     <style>
            #font-color{
                color: white;
            }
            
            #mobile-demo{
                background: rgba(69,139,116, .5);
            }
         
            
            #mobile-li{
                background-color: #53868B;
            }
            #mobile-search-label{
                color: rgba(0,0,0,.3);
                
            }
            #nav-upper{
                background: rgba(69,139,116, .1);
            }
            #fullscreen-search-label{
                color: white;
            }
            #fullscreen-search-label{
                color: rgba(0,0,0,.3);
            }
         .{
             background-color: rgba(0,255,0,0.3);
         }
       
           
        </style>
         
    <!-- CREATED BY: RENZ -->
         
  </nav>
</div>