<!DOCTYPE html>
<html>
<head>
	<!-- Author: Besario, Felmerald Calago-->
	<title><?php echo $title; ?></title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  			
  			<!-- Felmerald key for: Search Engine Optimization Meta tags -->
  			<meta name="robots" content="noodp,noydir"/>
  			<meta name="description" content="" />
			<meta name="keywords" content="" />
			<meta name="rating" content="general" />
			<meta name="copyright" content="" />
			<meta name="expires" content="never" />
			<meta name="distribution" content="global" />
				<meta property="og:locale" content="en_US" />
				<meta property="og:type" content="website" />
				<meta property="og:title" content="" />
				<meta property="og:description" content="" />
				<meta property="og:url" content="" />
				<meta property="og:site_name" content="u" />
					<!-- verification key - very important for ranking -->
					<meta name="alexaVerifyID" content="" />
					<meta name="msvalidate.01" content="" />
					<meta name="google-site-verification" content="" />

  			<!-- end for SEO -->

  			<!-- cascading stylesheet -->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/materialize.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/mystyle.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>css/renzdaitol.css">	
    
</head>
<!--<body style="background-color: #373b50">-->
<body style="background-color: #e7e5e6;">