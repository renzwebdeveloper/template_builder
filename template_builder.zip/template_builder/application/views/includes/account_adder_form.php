<html>
    <title>
    </title>
    
    <head>
    </head>
    
    <body>
        <?php echo form_open(); ?>
        <?php echo form_close(); ?>
    </body>
</html>
