<html>
    
    <body style="background-image: url(<?php echo base_url(); ?>images/background/bg3.jpg); background-repeat: no-repeat; background-size: cover;">
        
        
        <center>
        <div style="background-color: grey; opacity: 0.5; margin-top: 100px;"  class="container">
            
 <div class="row">
 <?php echo form_open('user_controller/myauth');  ?>
     
     
    <div class="col s12">
        <!-- EMAIL TEXT BOX-->
      <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">email</i>
            <input type="email" name="email">
            <p style="color:red"><?php echo form_error('email'); ?></p>
         
        </div>
    </div>
        
         <!-- PASSWORD TEXT BOX-->
     <div class="row">
        <div class="input-field col s12">
          <i class="material-icons prefix">vpn_key</i>
           <input type="password" name="password">
          <!--<input name="password" id="icon_telephone" type="password" >-->
            <p style="color:red"><?php echo form_error('password'); ?></p>
         
        </div>
      </div>
        
         <!-- BUTTONS -->
         
        <div class="row">
            <div class="input-field col s6">
                <div class="waves-effect waves-light btn">
                 <input type="submit" value="login">
                </div>
                
            </div>
            
        </div>
    
      
        <!--
        <div class="input-field col s6">
        <a class="waves-effect waves-light btn"><i class="material-icons left">cloud</i>cancel</a>    
        </div>
    -->
    </div>
        
    </div>
     <?php echo form_close(); ?>
  </div>
        
        </div>
            </center>
         
    </body>
</html>