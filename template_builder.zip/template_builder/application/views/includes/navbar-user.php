  <nav class="blue-grey darken-1">
  <div class="container">
    <div class="nav-wrapper">
      <!-- <a href="#" class="brand-logo"><img src="<?php echo base_url(); ?>images/logo/horizontal-logo.png" class="img-responsive logo" style="height: 57px;margin-top: 2px;"></a> -->
    
    </div>
  </div>
</nav>