<?php 

header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
header("Pragma: no-cache");
$user_id = $this->session->userdata('login_id');
$email = $this->session->userdata('login_email');
$password = $this->session->userdata('login_password');
$sessionData = array(
	'id'=>$user_id,
	'email'=>$email,
	'password'=>$password
);

$checkUserSession =$this->db->get_where('account',$sessionData);
if($checkUserSession->num_rows() == 0){

	$checkAdmin = $this->db->get_where('account',$sessionData);
	if($checkAdmin->num_rows() != 0){
		 redirect(base_url().'index');
		 
	}else{
		
		 $data = array(
            'login_id' => '',
            'login_email' => '',
            'login_password' => '',
            'login' => ''
        );
        $this->session->unset_userdata($data);
        // $this->session->sess_destroy();
        
	}
}else{
	redirect(base_url().'dashboard');
}

?>
