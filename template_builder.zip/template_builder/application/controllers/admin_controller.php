<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Admin_Controller extends CI_Controller{
		// @param load login page of admin
		public function template_login(){
			$this->load->view('adminIncludes/session/session_login');
			$data['title'] ="Welcome to Template Builder Admin Login";
			$data['login'] ="Administrator Login";
			$this->load->view('adminIncludes/header_footer/admin_header',$data);
			$this->load->view('administrator/template_login',$data);
			$this->load->view('adminIncludes/header_footer/admin_footer');
		}
		// @param load and with session dashboard
		public function dashboard(){
			if($this->session->userdata('login_id') != '' && $this->session->userdata('login_email') != '' && $this->session->userdata('login_password') != '' && $this->session->userdata('login') == TRUE){
		

			$data['getdetails'] = $this->admin_model->admin_details();
			$data['lastloggedin'] = $this->admin_model->last_loggedInAdmin();
			$data['userlastloggedin'] = $this->admin_model->users_lastLoggedIn();
			$data['displayuser'] = $this->admin_model->get_userAccount();
			$data['getrecentActivities'] = $this->admin_model->get_recent();
			$data['getRecents'] = $this->admin_model->showAll_recents();

			$this->load->view('adminIncludes/session/dashboard_session');
			$data['title'] ="Welcome to Administrator Dashboard";
			$this->load->view('adminIncludes/header_footer/admin_header',$data);
			$this->load->view('administrator/dashboard',$data);
			$this->load->view('adminIncludes/header_footer/admin_footer');
			}else{
				redirect(base_url().'template_login');
				exit();
			}
		}
		// @param adding template
		public function dashboard_addTemplate(){
			$data['lastloggedin'] = $this->admin_model->last_loggedInAdmin();
			$data['getdetails'] = $this->admin_model->admin_details();
			$data['getrecentActivities'] = $this->admin_model->get_recent();
			$data['getRecents'] = $this->admin_model->showAll_recents();
			
			$data['title'] = "Dashboard Add Templates";
			$this->load->view('adminIncludes/session/dashboard_session');
			$this->load->view('adminIncludes/header_footer/admin_header',$data);
			$this->load->view('administrator/dashboard_addTemplate',$data);
			$this->load->view('adminIncludes/header_footer/admin_footer');
		}
		// @param this will check the login info
		public function admin_login(){
			$this->form_validation->set_rules('email','Email','trim|required|xss_clean');
			$this->form_validation->set_rules('password','Password','trim|required|xss_clean');
			if($this->form_validation->run() == FALSE){
				$this->template_admin();
			}else{
				$email = $this->input->post('email');
				$password = $this->input->post('password');
				$this->admin_model->admin_login($email,$password);
			}
		}
		// @param this will destroy the login session
		public function admin_logout(){
			// this is for last_login tracking time
				$email = $this->session->userdata('login_id');

				$last_login=date('Y-m-d H:i:s', time());

				$data = array(
					'last_login'=>$last_login
					);
				$this->db->where('id',$email);
				$this->db->update('account',$data);
			// end here
			$data = array(
				'login_id' => '',
				'login_email' => '',
				'login_password'=> '',
				'login'=>''
				);
			$this->session->unset_userdata($data);
			$this->session->sess_destroy();
			redirect(base_url().'template_login');
			exit();
		}
		// @param admin add user query
		public function dashboard_add_userAccount(){
			$this->form_validation->set_rules('firstname','<strong><span class="text-warning glyphicon glyphicon-warning-sign"></span> Firstname</strong>','required|trim|xss_clean');
			$this->form_validation->set_rules('lastname','<strong><span class="text-warning glyphicon glyphicon-warning-sign"></span> Lastname</strong>','required|trim|xss_clean');
			$this->form_validation->set_rules('email','<strong><span class="text-warning glyphicon glyphicon-warning-sign"></span> Email Address</strong>','trim|xss_clean|valid_email|required|is_unique[account.email]');
		$this->form_validation->set_rules('password','<strong><span class="text-warning glyphicon glyphicon-warning-sign"></span> Password </strong>','trim|required|min_length[12]|matches[cpassword]|xss_clean');
			$this->form_validation->set_rules('cpassword','<strong><span class="text-warning glyphicon glyphicon-warning-sign"></span> Confirmation Password</strong>','trim|required|xss_clean');
			if($this->form_validation->run() == FALSE){
				$this->dashboard();
			}else{


				$firstname = $this->input->post('firstname');
				$lastname = $this->input->post('lastname');
				$email = $this->input->post('email');
				$password = $this->input->post('password');
				$created = $this->input->post('created');
				$role = $this->input->post('role');
				$this->admin_model->dashboard_add_userAccount($firstname,$lastname,$email,$password,$created,$role);
				// continue ugma 


			}

		}
		// @param delete account user
		public function dashboard_deleteuseraccount(){
			$id = $this->input->get('id');
			$this->admin_model->dashboard_deleteuseraccount($id);
		}
		// @param update account user
		public function dashboard_updateUserAccount(){
			$this->form_validation->set_rules('firstname','','xss_clean');
			$this->form_validation->set_rules('lastname','','xss_clean');
			$this->form_validation->run();

			$id = $this->input->post('id');
			$firstname = $this->input->post('firstname');
			$lastname = $this->input->post('lastname');
			$modified = $this->input->post('modified');
			$this->admin_model->dashboard_updateUserAccount($id,$firstname,$lastname,$modified);
		}



		// param send mail
		public function email(){
			$this->load->library('email');
			$config['protocol'] = "smtp";
			// does not have to be gmail
			$config['smtp_host'] = 'ssl://smtp.gmail.com'; 
			$config['smtp_port'] = '465';
			$config['smtp_user'] = 'felmeraldb@gmail.com';
			$config['smtp_pass'] = 'chrisrald';
			$config['mailtype'] = 'html';
			$config['charset'] = 'utf-8';
			$config['newline'] = "\r\n";
			$config['wordwrap'] = TRUE;

			$this->email->initialize($config);


			$this->email->from($this->input->post('email'), $this->input->post('name'));
			$this->email->to('felmeraldb@gmail.com'); 
			

			$this->email->subject('Email Test');
			$this->email->message($this->input->post('message'));	

			if($this->email->send()){
				echo 'success';
			}else{

			echo $this->email->print_debugger();	
			}

		}
        
       
       

		// 

	}
	// end