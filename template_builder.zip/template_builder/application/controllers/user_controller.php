<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_Controller extends CI_Controller{

	// for requesting and loading the http address for index and header and footer
 	
    public function index(){

 		$data['title'] ="Welcome to Template Builder";
        $data['header'] = "Login";
 		$this->load->view('includes/header',$data);
 		$this->load->view('includes/navbar-user');
 		$this->load->view('index',$data);
 		$this->load->view('includes/footer');
        $this->load->view('user_panel/user_session_login');
 	}
    
 	public function home(){
 		$data['title'] ="Welcome to Template Builder | Account";

 		$this->load->view('includes/header',$data);
 		$this->load->view('includes/account/menu');
 		$this->load->view('user_panel/home',$data);
 		$this->load->view('includes/account/fixed-footer');
 		$this->load->view('includes/footer');
 	}
     
     public function user_dashboard(){
         
         if($this->session->userdata('login_id')!= '' &&
            $this->session->userdata('login_email')!= '' &&
            $this->session->userdata('login_password')!= '' &&
            $this->session->userdata('login')== TRUE
           ){
             
         $data['title']="My Account";
         $this->load->view('includes/header',$data);
         $information['user_details']=$this->user_model->retrieve_data_user();
         $this->load->view('includes/user_navbar-user',$information);
         $this->load->view('includes/user_dashboard_body2');
         $this->load->view('includes/renzblankfooter');
        
             
         }else{
             redirect(base_url().'index');
             exit();
             
         }
        
     }
     
     public function user_login(){
         $this->form_validation->set_rules('email','Email','trim|required|xss_clean');
         
         $this->form_validation->set_rules('password','Password','trim|required|xss_clean');
         
         if($this->form_validation->run() == FALSE){
             $this->index();
             
         }else{
            
              $email=$this->input->post('email');
              $password=$this->input->post('password');
              $this->user_model->user_login($email,$password);
             
         }
         
     }
     
      public function user_logout(){
         $data = array(
            'login_id' => '',
             'login_email' => '',
             'login_password' => '',
             'login' => '',
             );
          $this->session->unset_userdata($data);
          $this->session->sess_destroy();
          redirect(base_url().'index');
          exit();
         
     }
     
     public function update_user_data2(){
         $new_password=$this->input->post('new_password');
         $confirm_password=$this->input->post('confirm_password');
         
         if($new_password != '' && $confirm_password != '' && $new_password == $confirm_password){
              
           $password=$this->input->post('new_password');
           $this->user_model->update_user_data($id,$firstname,$lastname,$email,$password);
         }
         else{
             redirect(base_url().'profile');
         }
         
          $this->form_validation->set_rules('firstname','Firstname','trim|required|xss_clean');
          $this->form_validation->set_rules('lastname','Lastname','trim|required|xss_clean');
          $this->form_validation->set_rules('email','Email','trim|required|xss_clean');
          $this->form_validation->set_rules('password','Password','trim|required|xss_clean');
         
       
         if($this->form_validation->run() == FALSE){
             redirect(base_url().'profile');
             
         }else{
            $id=$this->input->post('id');
             $firstname=$this->input->post('firstname');
             $lastname=$this->input->post('lastname');
             $email=$this->input->post('email');
             $this->user_model->update_user_data($id,$firstname,$lastname,$email,$password);
        
             
             
         }
             
     }
     
     public function profile(){
           if($this->session->userdata('login_id')!= '' &&
            $this->session->userdata('login_email')!= '' &&
            $this->session->userdata('login_password')!= '' &&
            $this->session->userdata('login')== TRUE
           ){
             
         $data['title']="My Account";
         $this->load->view('includes/header',$data);
         $information['user_details']=$this->user_model->retrieve_data_user();
         $this->load->view('includes/user_navbar-user.php',$information);
         
         $this->load->view('includes/user_dashboard_body.php',$information);
         $this->load->view('includes/footer');
             
         }else{
             redirect(base_url().'index');
             exit();
         }
     }
    
     public function account_adder(){
            $this->load->view('includes/account_adder_form');
        }
     
   

}// end