<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "user_controller";

// user side
$route['index'] = "user_controller/index";
$route['home'] ="user_controller/home";
$route['user_dashboard']="user_controller/user_dashboard";
$route['user_login']="user_controller/user_login";
$route['user_logout']="user_controller/user_logout";
$route['update_user_data2']="user_controller/update_user_data2";
$route['profile']="user_controller/profile";


// admin side here
$route['template_login']="admin_controller/template_login";
$route['dashboard'] ="admin_controller/dashboard";
$route['dashboard_addTemplate'] ="admin_controller/dashboard_addTemplate";
// login details
$route['admin_login']="admin_controller/admin_login";
$route['admin_logout']="admin_controller/admin_logout";
// end
// for admin add user
$route['dashboard_add_userAccount']="admin_controller/dashboard_add_userAccount";
// for delete user
$route['dashboard_deleteuseraccount']="admin_controller/dashboard_deleteuseraccount";
// for update user
$route['dashboard_updateUserAccount']="admin_controller/dashboard_updateUserAccount";

$route['404_override'] = '';


/* End of file routes.php */
/* Location: ./application/config/routes.php */