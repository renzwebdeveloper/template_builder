<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Admin_model Extends CI_Model{

		// @param for requesting login
		public function admin_login($email,$password){
			$data = array(
					'email'=>$email,
					'password'=>sha1(sha1($password))
					
				);
			$query = $this->db->get_where('account',$data);
			if($query->num_rows() != 0){
					foreach($query->result() as $row):
							$user_id = $row->id;
							$sessionData = array(
									'login_id' => $row->id,
									'login_email' => $row->email, 
									'login_password' => $row->password, 
									'login' => TRUE
								);
							$this->session->set_userdata($sessionData);
							$this->session->set_flashdata(array('login_successful'=>'<div class="alert alert-dismissible alert-success">
											<button type="button" class="close" data-dismiss="alert"><i class="fa fa-close"></i></button>
											<strong><span class="fa fa-key text-warning"></span></strong> Welcome Administrator.
									</div>'));
							redirect(base_url().'dashboard');
							exit();
					endforeach;
			}else{
				$this->session->set_flashdata(array('login_error'=>'
					<div class="alert alert-dismissible alert-danger">
											<button type="button" class="close" data-dismiss="alert"><i class="fa fa-close"></i></button>
											<strong><span class="glyphicon glyphicon-warning-sign text-warning"></span></strong> Invalide email or password <a href="#" class="alert-link">Or Contact Administrator</a>.
					</div>
					'));
				redirect(base_url().'template_login');
				exit();
			}
		}

		// @param geting the user session names of admin
		public function admin_details(){
		$email = $this->session->userdata('login_id');
		$this->db->select('id,firstname,lastname,email,role,last_login');
		$this->db->from('account');
		$this->db->where('id',$email);
		$getUserQuery = $this->db->get();
		return $getUserQuery->result();
		
		}
		// @param get Last Logged In
		public function last_loggedInAdmin(){
				$email = $this->session->userdata('login_id');
				$this->db->select('id, last_login, role');
				$this->db->from('account');
				$this->db->where('id',$email);
				$queryGetlastLoggedIn = $this->db->get();
				return $queryGetlastLoggedIn->result();
		}
		// param get user's Logged In
		public function users_lastLoggedIn(){
			$email = $this->session->userdata('login_id');
			$query = $this->db->get('account'); 
			return $query->result();
				// return $query use in condition statement
		}
		// @param get user's account, that admin's added
		public function get_userAccount(){
			$this->db->select('*');
			$this->db->from('account');
			$this->db->order_by('id','desc');
			$queryUsersAccount = $this->db->get();
			return $queryUsersAccount->result();
		}
		// @param get recent activities and Joining Table for account and recent_activity and template
		// 3 tables joined
		public function get_recent(){
			$profile = $this->session->userdata('login_id');
			$this->db->select('account.id AS mem_id, recent_activity.id AS recent_id, times, downloaded, firstname, templaete.id AS temp_id, template_name');
			$this->db->from('recent_activity');
			$this->db->join('account','account.id = recent_activity.profile_id','left');
			$this->db->join('templaete','templaete.id = recent_activity.template_id','left');
			$this->db->order_by('recent_id','desc');
			$this->db->limit(6); // ang 6 ky limit
			$queryJoined = $this->db->get();
			return $queryJoined;
		}
		// @param show all recent offset 6
		public function showAll_recents(){
			$profile = $this->session->userdata('login_id');
			$this->db->select('account.id AS mem_id, recent_activity.id AS recent_id, times, downloaded, firstname, templaete.id AS temp_id, template_name');
			$this->db->from('recent_activity');
			$this->db->join('account','account.id = recent_activity.profile_id','left');
			$this->db->join('templaete','templaete.id = recent_activity.template_id','left');
			$this->db->order_by('recent_id','desc');
			$this->db->limit(20, 6); // 20 is limit offset is 6
			$queryOffset = $this->db->get();
			return $queryOffset->result();
		}

		// @param for inserting user account added by admin
		public function dashboard_add_userAccount($firstname,$lastname,$email,$password,$created,$role){

			date_default_timezone_set('Asia/Manila');
			$created = date('h:m:s a m/d/y');
			$data = array(
				'firstname'=>$firstname,
				'lastname'=>$lastname,
				'email'=>$email,
				'password'=>sha1(sha1($password)),
				'created'=>$created,
				'role'=>$role
				);
					$this->db->insert('account',$data);
					$this->session->set_flashdata(array('added_true'=>'<div class="alert alert-dismissible alert-success">
											<button type="button" class="close" data-dismiss="alert"><i class="fa fa-close"></i></button>
											<strong><span class="glyphicon glyphicon-ok text-warning"></span></strong> User Account Successfully Added! </a></div>'));
					redirect(base_url().'dashboard');
					exit();
		}
		// @param deleting account
		public function dashboard_deleteuseraccount($id){
			$this->db->where('id',$id)->delete('account');
			$this->session->set_flashdata(array('deleteUser_success' => '<div class="alert alert-dismissible alert-success">
											<button type="button" class="close" data-dismiss="alert"><i class="fa fa-close"></i></button>
											<strong><span class="glyphicon glyphicon-ok text-warning"></span></strong> Account Successfully Deleted ! </a></div>'));
			redirect(base_url().'dashboard');
			exit();
		}
		// @param update account
		public function dashboard_updateUserAccount($id,$firstname,$lastname,$modified){
			date_default_timezone_set('Asia/Manila');
			$modified = date('h:m:s a m/d/y');
			$data = array(
				'firstname'=>$firstname, 'lastname'=>$lastname, 'modified'=>$modified
				);
			$this->db->where('id',$id)->update('account',$data);
			$this->session->set_flashdata(array('update_success'=>'<div class="alert alert-dismissible alert-success">
											<button type="button" class="close" data-dismiss="alert"><i class="fa fa-close"></i></button>
											<strong><span class="glyphicon glyphicon-ok text-warning"></span></strong> Account Successfully Updated ! </a></div>'));
			redirect(base_url().'dashboard');
			exit();
		}



		// @param for time ago called in views
	function time_ago($timestamp) {
    $output = ""; //string value to be returned
    $now = time();
    $createtime = strtotime($timestamp); //mysql timestamp 
    $difference = abs($now - $createtime);

    $years = floor($difference / (365*60*60*24));
    $months = floor(($difference-$years*365*60*60*24)/(30*60*60*24));
    $days = floor(($difference - $years*365*60*60*24-$months*30*60*60*24)/(60*60*24));
    $hours = floor($difference / 3600);
    $minutes = floor($difference / 60);
    $seconds = floor($difference);


    if ($output == "") {//to check whether it is years old
        if ($years > 1) {
            $output = $years . " years ago";
        } elseif ($years == 1) {
            $output = $years . " year ago";
        }
    }

    if ($output == "") {//to check whether it is months old
        if ($months > 1) {
            $output = $months . " months ago";
        } elseif ($months == 1) {
            $output = $months . " month ago";
        }
    }

    if ($output == "") {//to check whether it is days old
        if ($days > 1) {
            $output = $days . " days ago";
        } elseif ($days == 1) {
            $output = $days . " day ago";
        }
    }

    if ($output == "") {//to check whether it is hours old
        if ($hours > 1) {
            $output = $hours . " hours ago";
        } elseif ($hours == 1) {
            $output = $hours . " hour ago";
        }
    }
     
    if ($output == "") {//to check whether it is minutes old
        if ($minutes > 1) {
            $output = $minutes . " minutes ago";
        } elseif ($minutes == 1) {
            $output = $minutes . " minute ago";
        }
    }
    
    if ($output == "") {//to check whether it is seconds old
        if ($seconds > 1) {
            $output = $seconds . " seconds ago";
        } elseif ($seconds == 1) {
            $output = $seconds . " second ago";
        }
    }
    return $output;
}




	}// end