<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class User_model extends CI_Model{

		public function user_login($email,$password){
            //$data = array('email'=>$email,'password'=>sha1(sha1($password)));
            $data = array('email'=>$email,'password'=>$password);
            
             $query = $this->db->get_where('account',$data);
        
        if($query->num_rows() != 0){
            foreach($query->result() as $row):
                $user_id = $row->id;
                $sessionData = array(
                    'login_id' => $row->id,
                    'login_email' => $row->email,
                    'login_password' => $row->password,
                    'login' => TRUE
                    );
                $this->session->set_userdata($sessionData);
                redirect(base_url().'user_dashboard');
                exit();
                
                endforeach;
                                    
                                    
            }else{
                $this->session->set_flashdata(array('login_error'=>'<div class="card-panel" style="width: 100%;">
                    <p class="text-warning">
                        <i class=material-icons">Warning:</i>
                        Invalid Username or Password!
                    </p>
                </div>
                '));
            redirect(base_url().'index');
                exit();
            }
        }
        
        public function retrieve_data_user(){
            $email=$this->session->userdata('login_id');
            $role='user';
            
            $this->db->select('id,firstname,lastname,email,role,password');
            $this->db->from('account');
            $this->db->where('id',$email);
            $this->db->where('role',$role);
            $getUserQuery = $this->db->get();
            
           
            return $getUserQuery->result();
        }
        
        public function update_user_data($id,$firstname,$lastname,$email,$password){
            //FOR UPDATING USERS' DATA
            
             $data = array(
                 'id'=>$id,
               'firstname' => $firstname,
               'lastname' => $lastname,
               'email' => $email,
               'password' => $new_password,
            );

$this->db->where('id', $id);
$this->db->update('account', $data); 
            redirect(base_url().'user_dashboard');
                exit();

        }
        
            
        }
        
       




	