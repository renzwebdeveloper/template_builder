        function openNav(){
            document.getElementById("mySidenav").style.width="250px";
            document.getElementById("main").style.marginLeft="250px";
            document.getElementById("closebtn").style.visibility="visible";
            document.getElementById("openbtn").style.visibility="hidden";
            document.getElementById("side-nav-head").style.visibility="visible";
            document.getElementById("side-nav-content").style.visibility="visible";
        }
        function closeNav(){
            document.getElementById("mySidenav").style.width="30px";
            document.getElementById("main").style.marginLeft="30px";
            document.getElementById("closebtn").style.visibility="hidden";
            document.getElementById("openbtn").style.visibility="visible";
            document.getElementById("side-nav-head").style.visibility="hidden";
            document.getElementById("side-nav-content").style.visibility="hidden";
            
        }

